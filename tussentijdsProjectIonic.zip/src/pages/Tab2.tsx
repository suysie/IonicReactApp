import React, {useEffect, useState} from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonIcon, IonItem, IonLabel } from '@ionic/react';
import { ellipse } from 'ionicons/icons';
import './Tab2.css';

import { koekje } from '../mqtt'

const TOPIC = 'RaspInput'

const Tab2: React.FC = () => {

  const [pin, setPin] = useState<string>()

  const client = koekje.getClient()
  client.subscribe(TOPIC)
  client.on('message', (topic: string, message: string) => {
    if(topic === TOPIC){
      setPin(message)
      console.log(message.toString())
    }
  })

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>inputs</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Inputs</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonItem>
          <IonLabel>input 1</IonLabel>
          <IonIcon icon={ellipse} slot="end"></IonIcon>
        </IonItem>
        <IonItem>
          <IonLabel>input 2</IonLabel>
          <IonIcon icon={ellipse} slot="end"></IonIcon>
        </IonItem>
      </IonContent>
    </IonPage>
  );
};

export default Tab2;
