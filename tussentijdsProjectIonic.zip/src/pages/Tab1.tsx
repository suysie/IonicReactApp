import React, {useEffect, useState} from 'react';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar, IonItem, IonToggle } from '@ionic/react';
import './Tab1.css';

import { koekje } from '../mqtt'

const TOPIC = 'hallo'

const Tab1: React.FC = () => {

  const [pin, setPin] = useState<string>()

  const client = koekje.getClient()
  client.subscribe(TOPIC)
  client.on('message', (topic: string, message: string) => {
    if(topic === TOPIC){
      setPin(message)
      console.log(message.toString())
    }
  })

  return (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>outputs</IonTitle>
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Outputs</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonItem><IonToggle color="light" />change Output 1</IonItem>
        <IonItem><IonToggle color="light" />change Output 2</IonItem>
      </IonContent>
    </IonPage>
  );
};

export default Tab1;
