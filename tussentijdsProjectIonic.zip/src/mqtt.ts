const mqtt   = require('mqtt');

class MQTT {
    private client: any; 
    constructor(){
        this.client  = mqtt.connect('ws://test.mosquitto.org:8080/ws');
    }

    getClient(){
        return this.client
    }
}

const koekje = new MQTT()
export { koekje }
